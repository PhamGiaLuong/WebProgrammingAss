<?php include('../Header.php');
include 'function.php'; ?>
<!-- tab Quản lý -->
<div class="container">
    <!-- Tab Navigation -->
    <div class="px-2" style="background-color: #c8d6e5;">
        <ul class="nav nav-underline d-flex flex-nowrap justify-content-between gap-3">
            <li class="nav-item">
                <a class="nav-link text-dark active" data-bs-toggle="pill" href="#orders-list">DANH SÁCH ĐƠN HÀNG</a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-dark" data-bs-toggle="pill" href="#sales">DOANH SỐ</a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-dark" data-bs-toggle="pill" href="#members-list">DANH SÁCH NHÂN VIÊN</a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-dark" data-bs-toggle="pill" href="#products-list">DANH SÁCH SẢN PHẨM</a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-dark" data-bs-toggle="pill" href="#news">TIN TỨC</a>
            </li>
        </ul>
    </div>
    <!-- Tab Content -->
    <div class="tab-content mt-3 col-12">
        <!-- Tab Đơn hàng-->
        <div class="tab-pane fade" id="orders-list">
            <h1 class="col-12 text-center m-2">DANH SÁCH ĐƠN HÀNG</h1>
            <?php
            // Kết nối đến cơ sở dữ liệu
            $conn = connectToDatabase();

            // Truy vấn dữ liệu đơn hàng
            $sql_orders = "SELECT 
                  orders.order_id, 
                  orders.order_date, 
                  orders.total_amount, 
                  account.account_Name, 
                  account.account_Phone, 
                  account.account_Address
              FROM orders 
              JOIN account ON orders.account_email = account.account_email";
            $result_orders = $conn->query($sql_orders);
            ?>

            <!-- Thông tin đơn hàng -->
            <div class="col-12 overflow-x-auto">
                <table class="table table-hover mt-1 col-12">
                    <thead class="table-dark">
                        <tr>
                            <th>Mã đơn hàng</th>
                            <th>Tên khách hàng</th>
                            <th>Số điện thoại</th>
                            <th>Địa chỉ</th>
                            <th>Số lượng</th>
                            <th>Số tiền</th>
                            <th>Thời gian mua</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        // Hiển thị dữ liệu đơn hàng
                        while ($order = $result_orders->fetch_assoc()):
                            // Truy vấn chi tiết đơn hàng
                            $sql_order_details = "SELECT 
                                         order_items.product_id, 
                                         order_items.quantity, 
                                         order_items.price, 
                                         products.product_Name, 
                                         products.product_IMG 
                                      FROM order_items 
                                      JOIN products ON order_items.product_id = products.product_ID 
                                      WHERE order_id = ?";
                            $stmt_order_details = $conn->prepare($sql_order_details);
                            $stmt_order_details->bind_param("i", $order['order_id']);
                            $stmt_order_details->execute();
                            $result_order_details = $stmt_order_details->get_result();
                            $order_details = $result_order_details->fetch_all(MYSQLI_ASSOC);
                            $stmt_order_details->close();
                        ?>
                            <tr onclick="toggleDetails('details-<?= $order['order_id']; ?>')">
                                <td><?= $order['order_id']; ?></td>
                                <td><?= htmlspecialchars($order['account_Name']); ?></td>
                                <td><?= htmlspecialchars($order['account_Phone']); ?></td>
                                <td><?= htmlspecialchars($order['account_Address']); ?></td>
                                <td><?= array_sum(array_column($order_details, 'quantity')); ?></td>
                                <td><?= number_format($order['total_amount'], 0, ',', '.') . ' VND'; ?></td>
                                <td><?= $order['order_date']; ?></td>
                            </tr>
                            <!-- Bảng chi tiết đơn hàng -->
                            <tr id="details-<?= $order['order_id']; ?>" class="collapse">
                                <td colspan="7">
                                    <table class="table mb-0">
                                        <thead class="table-secondary">
                                            <tr>
                                                <th>STT</th>
                                                <th>Hình ảnh</th>
                                                <th>Tên sản phẩm</th>
                                                <th>Số lượng</th>
                                                <th>Đơn giá</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($order_details as $index => $item): ?>
                                                <tr>
                                                    <td><?= $index + 1; ?></td>
                                                    <td><img src="<?= htmlspecialchars($item['product_IMG']); ?>" alt="<?= htmlspecialchars($item['product_Name']); ?>" style="width: 60px;"></td>
                                                    <td><?= htmlspecialchars($item['product_Name']); ?></td>
                                                    <td><?= $item['quantity']; ?></td>
                                                    <td><?= number_format($item['price'], 0, ',', '.') . ' VND'; ?></td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <!-- Tab Doanh số -->
        <div class="tab-pane fade" id="sales">
            <h1 class="col-12 text-center m-2">
                DOANH SỐ
            </h1>
            <div class="col-12 d-flex flex-wrap justify-content-between gap-3">
                <?php
                // Kết nối đến cơ sở dữ liệu
                $conn = connectToDatabase();
                // Truy vấn doanh thu
                $sql_revenue = "SELECT SUM(total_amount) AS total_revenue FROM orders";
                $result_revenue = $conn->query($sql_revenue);
                $total_revenue = ($result_revenue->num_rows > 0) ? $result_revenue->fetch_assoc()['total_revenue'] : 0;

                // Truy vấn số lượng sản phẩm bán ra
                $sql_products_sold = "SELECT SUM(quantity) AS total_products_sold FROM order_items";
                $result_products_sold = $conn->query($sql_products_sold);
                $total_products_sold = ($result_products_sold->num_rows > 0) ? $result_products_sold->fetch_assoc()['total_products_sold'] : 0;

                // Truy vấn số lượng khách hàng mới
                $sql_new_customers = "SELECT COUNT(DISTINCT account_email) AS total_new_customers FROM orders WHERE order_date > DATE_SUB(CURDATE(), INTERVAL 30 DAY)";
                $result_new_customers = $conn->query($sql_new_customers);
                $total_new_customers = ($result_new_customers->num_rows > 0) ? $result_new_customers->fetch_assoc()['total_new_customers'] : 0;

                $conn->close();
                ?>

                <div class="col-md-3 col-12 border rounded-3 p-2 d-flex flex-wrap bg-secondary bg-opacity-25">
                    <div class="col-3 bg-success d-flex justify-content-center align-items-center text-white">
                        <i class="bi bi-cash-stack fs-3"></i>
                    </div>
                    <div class="col-9 px-2">
                        <div><strong>Doanh thu</strong></div>
                        <div><?= number_format($total_revenue, 0, ',', '.') . ' VND'; ?></div>
                    </div>
                </div>

                <div class="col-md-3 col-12 border rounded-3 p-2 d-flex flex-wrap bg-secondary bg-opacity-25">
                    <div class="col-3 bg-primary d-flex justify-content-center align-items-center text-white">
                        <i class="bi bi-bag fs-3"></i>
                    </div>
                    <div class="col-9 px-2">
                        <div><strong>Sản phẩm bán ra</strong></div>
                        <div><?= number_format($total_products_sold, 0, ',', '.') . ' sản phẩm'; ?></div>
                    </div>
                </div>

                <div class="col-md-3 col-12 border rounded-3 p-2 d-flex flex-wrap bg-secondary bg-opacity-25">
                    <div class="col-3 bg-info d-flex justify-content-center align-items-center text-white">
                        <i class="bi bi-person-add fs-3"></i>
                    </div>
                    <div class="col-9 px-2">
                        <div><strong>Khách hàng mới</strong></div>
                        <div><?= number_format($total_new_customers, 0, ',', '.') . ' người'; ?></div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Tab Danh sách thành viên -->
        <div class="tab-pane fade" id="members-list">
            <div class="col-md-3 col-12 text-center p-2 mb-2" style="background-color: #222f3e;">
                <a href="AddUser.php" style="color: white;">
                    <i class="bi bi-person-plus fs-4"></i> Thêm nhân viên mới
                </a>
            </div>
            <h1 class="col-12 text-center m-2">
                DANH SÁCH NHÂN VIÊN
            </h1>
            <?php
            // Kết nối đến cơ sở dữ liệu
            $conn = connectToDatabase();

            // Truy vấn dữ liệu nhân viên
            $sql = "SELECT staff_id, staff_name, staff_phone, staff_email, staff_address FROM staff";
            $result = $conn->query($sql);

            // Kiểm tra nếu có nhân viên
            if ($result->num_rows > 0) {
                echo '<div class="overflow-x-auto">';
                echo '<table class="table text-start table-hover">';
                echo '<thead class="table-dark">';
                echo '<tr>';
                echo '<th>Id</th>';
                echo '<th>Tên nhân viên</th>';
                echo '<th>Số điện thoại</th>';
                echo '<th>Email</th>';
                echo '<th>Địa chỉ</th>';
                echo '</tr>';
                echo '</thead>';
                echo '<tbody>';

                // Hiển thị dữ liệu nhân viên
                while ($row = $result->fetch_assoc()) {
                    echo '<tr style="vertical-align: middle;">';
                    echo '<td>' . $row['staff_id'] . '</td>';
                    echo '<td>' . $row['staff_name'] . '</td>';
                    echo '<td>' . $row['staff_phone'] . '</td>';
                    echo '<td>' . $row['staff_email'] . '</td>';
                    echo '<td>' . $row['staff_address'] . '</td>';
                    echo '</tr>';
                }

                echo '</tbody>';
                echo '</table>';
                echo '</div>';
            } else {
                echo '<p class="text-center">Không có nhân viên nào.</p>';
            }

            $conn->close();
            ?>
        </div>

        <!-- Tab Danh sách sản phẩm -->
        <div class="tab-pane fade" id="products-list">
            <div class="col-md-3 col-12 text-center p-2 mb-2" style="background-color: #222f3e;">
                <a href="/Assignment/Tabs/AddProduct.php" style="color: white;">
                    <i class="bi bi-database-add fs-4"></i> Thêm sản phẩm mới
                </a>
            </div>
            <h1 class="col-12 text-center m-2">DANH SÁCH SẢN PHẨM</h1>

            <?php

            // Kết nối đến cơ sở dữ liệu
            $conn = connectToDatabase();

            // Truy vấn dữ liệu sản phẩm
            $sql = "SELECT product_ID, product_IMG, product_Name, product_Description, product_Price, product_Number FROM products";
            $result = $conn->query($sql);

            // Kiểm tra nếu có sản phẩm
            if ($result->num_rows > 0) {
                echo '<div class="overflow-x-auto">';
                echo '<table class="table text-start table-hover">';
                echo '<thead class="table-dark">';
                echo '<tr>';
                echo '<th>Id</th>';
                echo '<th>Hình ảnh</th>';
                echo '<th>Tên sản phẩm</th>';
                echo '<th>Mô tả</th>';
                echo '<th>Giá</th>';
                echo '<th>Tồn kho</th>';
                echo '<th>Hành động</th>';
                echo '</tr>';
                echo '</thead>';
                echo '<tbody>';

                // Hiển thị dữ liệu sản phẩm
                while ($row = $result->fetch_assoc()) {
                    echo '<tr style="vertical-align: middle;">';
                    echo '<td>' . $row['product_ID'] . '</td>';
                    echo '<td><img src="' . $row['product_IMG'] . '" alt="' . $row['product_Name'] . '" style="width: 60px;"></td>';
                    echo '<td>' . $row['product_Name'] . '</td>';
                    echo '<td>' . $row['product_Description'] . '</td>';
                    echo '<td>' . number_format($row['product_Price'], 0, ',', '.') . ' VND</td>';
                    echo '<td>' . $row['product_Number'] . '</td>';
                    echo '<td class="d-flex gap-2 border-0">';
                    echo '<a class="btn btn-danger" href="deleteProduct.php?id=' . $row['product_ID'] . '"><i class="bi bi-trash"></i></a>';
                    echo '<a class="btn btn-primary" href="editProduct.php?id=' . $row['product_ID'] . '"><i class="bi bi-pencil-square"></i></a>';
                    echo '</td>';
                    echo '</tr>';
                }

                echo '</tbody>';
                echo '</table>';
                echo '</div>';
            } else {
                echo '<p class="text-center">Không có sản phẩm nào.</p>';
            }

            $conn->close();
            ?>
        </div>

        <!-- Tab Tin tức -->
        <div class="tab-pane fade" id="news">
            <div class="col-md-3 col-12 text-center p-2 mb-2" style="background-color: #222f3e;">
                <a href="AddNews.php" style="color: white;">
                    <i class="bi bi-plus-square fs-4"></i> Thêm tin tức mới
                </a>
            </div>
            <h1 class="col-12 text-center m-2">DANH SÁCH TIN TỨC</h1>
            <?php
            // Kết nối đến cơ sở dữ liệu
            $conn = connectToDatabase();

            // Truy vấn dữ liệu tin tức
            $sql = "SELECT news_id, image, title, publish_date, description, link FROM news";
            $result = $conn->query($sql);

            // Kiểm tra nếu có tin tức
            if ($result->num_rows > 0) {
                echo '<div class="overflow-x-auto">';
                echo '<table class="table text-start table-hover">';
                echo '<thead class="table-dark">';
                echo '<tr>';
                echo '<th>Ảnh minh họa</th>';
                echo '<th>Tiêu đề</th>';
                echo '<th>Ngày xuất bản</th>';
                echo '<th>Mô tả</th>';
                echo '<th>Link</th>';
                echo '<th>Hành động</th>';
                echo '</tr>';
                echo '</thead>';
                echo '<tbody>';

                // Hiển thị dữ liệu tin tức
                while ($row = $result->fetch_assoc()) {
                    echo '<tr style="vertical-align: middle;">';
                    echo '<td><img src="' . $row['image'] . '" alt="' . $row['title'] . '" style="width: 60px;"></td>';
                    echo '<td>' . $row['title'] . '</td>';
                    echo '<td>' . $row['publish_date'] . '</td>';
                    echo '<td>' . $row['description'] . '</td>';
                    echo '<td><a href="' . $row['link'] . '" target="_blank">' . $row['link'] . '</a></td>';
                    echo '<td class="d-flex gap-2 border-0">';
                    echo '<a class="btn btn-danger" href="deleteNews.php?id=' . $row['news_id'] . '"><i class="bi bi-trash"></i></a>';
                    echo '<a class="btn btn-primary" href="editNews.php?id=' . $row['news_id'] . '"><i class="bi bi-pencil-square"></i></a>';
                    echo '</td>';
                    echo '</tr>';
                }

                echo '</tbody>';
                echo '</table>';
                echo '</div>';
            } else {
                echo '<p class="text-center">Không có tin tức nào.</p>';
            }

            $conn->close();
            ?>
        </div>

    </div>
    <script>
        function toggleDetails(id) {
            const element = document.getElementById(id);
            element.classList.toggle('collapse');
        }
    </script>
    <?php include('../Footer.php'); ?>