<?php include('../Header.php'); ?>

<!-- Kiểm tra và bắt đầu phiên làm việc nếu chưa có -->
<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include 'function.php'; // Bao gồm file chứa hàm connectToDatabase

// Giả sử email người dùng đã lưu trong session
$email = $_SESSION['email'];

// Kết nối đến cơ sở dữ liệu
$conn = connectToDatabase();

// Lấy lịch sử đơn hàng từ cơ sở dữ liệu
$sql_orders = "SELECT order_id, account_email, order_date, total_amount FROM orders WHERE account_email = ? ORDER BY order_date DESC";
$stmt_orders = $conn->prepare($sql_orders);
$stmt_orders->bind_param("s", $email);
$stmt_orders->execute();
$result_orders = $stmt_orders->get_result();
$orderHistory = $result_orders->fetch_all(MYSQLI_ASSOC);

foreach ($orderHistory as &$order) {
    $order_id = $order['order_id'];
    $sql_items = "SELECT order_items.product_id, order_items.quantity, order_items.price, products.product_Name, products.product_IMG 
                  FROM order_items 
                  JOIN products ON order_items.product_id = products.product_ID 
                  WHERE order_id = ?";
    $stmt_items = $conn->prepare($sql_items);
    $stmt_items->bind_param("i", $order_id);
    $stmt_items->execute();
    $result_items = $stmt_items->get_result();
    $order['details'] = $result_items->fetch_all(MYSQLI_ASSOC);
}

$stmt_orders->close();
$conn->close();
?>

<!-- Lịch sử mua hàng -->
<div class="container my-3">
    <h1 class="text-center mb-4">Lịch sử đơn hàng của bạn</h1>

    <!-- Nút nhấn chuyển đến Giỏ hàng hiện tại -->
    <div class="col-12 d-flex justify-content-end">
        <div class="col-md-3 col-6 text-center p-2" style="background-color: #222f3e;">
            <a href="/Assignment/Tabs/Cart.php" style="color: white;"><i class="bi bi-basket3"></i> Xem giỏ hàng của bạn</a>
        </div>
    </div>

    <div class="overflow-x-auto">
        <table class="table table-hover mt-1">
            <thead class="table-dark">
                <tr>
                    <th>Mã đơn hàng</th>
                    <th>Số lượng</th>
                    <th>Số tiền</th>
                    <th>Thời gian mua</th>
                    <th>Trạng thái</th>
                    <th>Hành động</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($orderHistory as $order): ?>
                    <tr onclick="toggleDetails('details-<?= $order['order_id']; ?>')">
                        <td><?= $order['order_id']; ?></td>
                        <td><?= array_sum(array_column($order['details'], 'quantity')); ?></td>
                        <td><?= number_format($order['total_amount'], 0, ',', '.') . ' VND'; ?></td>
                        <td><?= $order['order_date']; ?></td>
                        <td>
                            <span class="badge rounded-pill text-bg-success">Đã giao</span>
                            <span class="badge rounded-pill text-bg-danger">Đã hủy</span>
                            <span class="badge rounded-pill text-bg-warning">Đang giao</span>
                        </td>
                        <td><button class="btn btn-dark" type="button">Xem chi tiết</button></td>
                    </tr>
                    <!-- Bảng chi tiết đơn hàng -->
                    <tr id="details-<?= $order['order_id']; ?>" class="collapse">
                        <td colspan="6">
                            <table class="table mb-0">
                                <thead class="table-secondary">
                                    <tr>
                                        <th>STT</th>
                                        <th>Hình ảnh</th>
                                        <th>Tên sản phẩm</th>
                                        <th>Số lượng</th>
                                        <th>Đơn giá</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($order['details'] as $index => $item): ?>
                                        <tr>
                                            <td><?= $index + 1; ?></td>
                                            <td><img src="<?= htmlspecialchars($item['product_IMG']); ?>" alt="<?= htmlspecialchars($item['product_Name']); ?>" style="width: 60px;"></td>
                                            <td><?= htmlspecialchars($item['product_Name']); ?></td>
                                            <td><?= $item['quantity']; ?></td>
                                            <td><?= number_format($item['price'], 0, ',', '.') . ' VND'; ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th colspan="4" class="text-end">Tổng giá trị đơn hàng:</th>
                                        <th><?= number_format($order['total_amount'], 0, ',', '.') . ' VND'; ?></th>
                                    </tr>
                                </tfoot>
                            </table>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php include('../Footer.php'); ?>

<script>
    function toggleDetails(id) {
        const element = document.getElementById(id);
        element.classList.toggle('collapse');
    }
</script>