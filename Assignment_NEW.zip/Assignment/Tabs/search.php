<?php include('../Header.php'); ?>

<?php
include 'function.php';
$conn = connectToDatabase();

// Lấy từ khóa tìm kiếm từ form
$query = isset($_GET['query']) ? $_GET['query'] : '';

if ($query) {
    // Tìm kiếm sản phẩm dựa trên tên
    $sql = "SELECT * FROM products WHERE product_Name LIKE ?";
    $stmt = $conn->prepare($sql);
    $searchQuery = "%" . $query . "%";
    $stmt->bind_param("s", $searchQuery);
    $stmt->execute();
    $result = $stmt->get_result();
    ?>
    <div class="container mt-4">
        <h2>Kết quả tìm kiếm cho: <?= htmlspecialchars($query, ENT_QUOTES, 'UTF-8'); ?></h2>
        <div class="row">
            <?php
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    ?>
                    <div class="col-md-3 col-6 mb-4 fade-in">
                        <a href="/Assignment/Tabs/ProductDetail.php?id=<?= $row['product_ID']; ?>" class="text-decoration-none text-dark">
                            <div class="card border-0">
                                <div class="col-12 d-flex justify-content-center align-items-center product-image">
                                    <img src="<?= htmlspecialchars($row['product_IMG'], ENT_QUOTES, 'UTF-8'); ?>" class="card-img-top" alt="<?= htmlspecialchars($row['product_Name'], ENT_QUOTES, 'UTF-8'); ?>" 
                                        onerror="this.onerror=null; this.src='https://static.vecteezy.com/system/resources/previews/017/173/007/original/can-not-load-corrupted-image-concept-illustration-flat-design-eps10-modern-graphic-element-for-landing-page-empty-state-ui-infographic-icon-vector.jpg';" 
                                        style="object-fit: contain; height: 100%;">
                                </div>
                                <div class="card-body p-1 text-center">
                                    <h5 class="card-title"><?= htmlspecialchars($row['product_Name'], ENT_QUOTES, 'UTF-8'); ?></h5>
                                    <p class="card-text"><?= number_format($row['product_Price'], 0, ',', '.'); ?> VND</p>
                                    <div class="col-12 d-flex justify-content-center">
                                        <a href="#" class="btn btn-danger"><i class="bi bi-cart-plus"></i> Thêm vào giỏ hàng</a>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <?php
                }
            } else {
                echo "<p>Không tìm thấy sản phẩm nào.</p>";
            }
            ?>
        </div>
    </div>
    <?php
    $stmt->close();
} else {
    echo "<p>Vui lòng nhập từ khóa tìm kiếm.</p>";
}

// Đóng kết nối
$conn->close();
?>

<?php include('../Footer.php'); ?>
