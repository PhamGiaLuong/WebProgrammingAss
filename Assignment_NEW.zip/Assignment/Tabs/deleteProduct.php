<?php
include 'function.php'; // Bao gồm file chứa hàm connectToDatabase

// Kiểm tra và bắt đầu phiên làm việc nếu chưa có
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Kiểm tra nếu có ID sản phẩm được cung cấp
if (isset($_GET['id'])) {
    $productId = $_GET['id'];

    // Kết nối đến cơ sở dữ liệu
    $conn = connectToDatabase();

    // Xóa sản phẩm
    $sql = "DELETE FROM products WHERE product_ID = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $productId);
    if ($stmt->execute()) {
        $_SESSION['message'] = "Sản phẩm đã được xóa thành công!";
    } else {
        $_SESSION['message'] = "Có lỗi xảy ra: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();

    header('Location: Manage.php'); // Chuyển hướng về trang Manage.php
    exit();
}
