<?php
include('../Header.php');
include 'function.php'; // Bao gồm file chứa hàm connectToDatabase

// Kiểm tra và bắt đầu phiên làm việc nếu chưa có
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Kiểm tra nếu có ID sản phẩm được cung cấp
if (isset($_GET['id'])) {
    $productId = $_GET['id'];

    // Kết nối đến cơ sở dữ liệu
    $conn = connectToDatabase();

    // Truy vấn thông tin sản phẩm
    $sql = "SELECT * FROM products WHERE product_ID = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $productId);
    $stmt->execute();
    $result = $stmt->get_result();
    $product = $result->fetch_assoc();

    $stmt->close();
    $conn->close();
}

// Kiểm tra nếu form đã được submit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $productId = $_POST['id'];
    $name = $_POST['name'];
    $price = $_POST['price'];
    $quantity = $_POST['quantity'];
    $image = $_POST['image'];
    $description = $_POST['description'];

    // Kết nối đến cơ sở dữ liệu
    $conn = connectToDatabase();

    // Cập nhật thông tin sản phẩm
    $sql = "UPDATE products SET product_Name = ?, product_Price = ?, product_Number = ?, product_IMG = ?, product_Description = ? WHERE product_ID = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sdissi", $name, $price, $quantity, $image, $description, $productId);
    if ($stmt->execute()) {
        $_SESSION['message'] = "Sản phẩm đã được cập nhật thành công!";
        header('Location: Manage.php'); // Chuyển hướng về trang Manage.php
        exit();
    } else {
        $message = "Có lỗi xảy ra: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>

<!-- chỉnh sửa sản phẩm -->
<div class="container d-flex justify-content-center">
    <div class="col-md-5 col-10 p-2 m-3 border border-1 rounded-5">
        <h3 class="col-12 text-center py-3">CHỈNH SỬA SẢN PHẨM</h3>
        <?php if (isset($message)): ?>
            <div class="alert alert-danger"><?php echo $message; ?></div>
        <?php endif; ?>
        <form action="editProduct.php?id=<?= $productId; ?>" method="POST" class="m-3">
            <input type="hidden" name="id" value="<?= $productId; ?>">
            <div class="user-box">
                <input type="text" id="name" name="name" value="<?= $product['product_Name']; ?>" required>
                <label for="name">Tên sản phẩm</label>
            </div>
            <div class="user-box">
                <input type="number" id="price" name="price" value="<?= $product['product_Price']; ?>" required>
                <label for="price">Giá</label>
            </div>
            <div class="user-box">
                <input type="number" id="quantity" name="quantity" value="<?= $product['product_Number']; ?>" required>
                <label for="quantity">Số lượng</label>
            </div>
            <div class="col-12 mb-2">
                <label for="image" class="form-label">Hình ảnh</label>
                <input type="text" name="image" id="image" class="form-control" value="<?= $product['product_IMG']; ?>">
            </div>
            <div class="col-12 mb-2">
                <label for="description" class="form-label">Mô tả sản phẩm</label>
                <textarea class="form-control" id="description" name="description" rows="4" required><?= $product['product_Description']; ?></textarea>
            </div>

            <div class="d-grid mt-3">
                <input type="submit" class="btn btn-dark" value="Cập nhật sản phẩm">
            </div>
        </form>
    </div>
</div>

<?php include('../Footer.php'); ?>