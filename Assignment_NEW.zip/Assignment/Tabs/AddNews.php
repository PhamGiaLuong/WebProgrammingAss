<?php
ob_start(); // Bắt đầu bộ đệm đầu ra
include('../Header.php');
include 'function.php'; // Bao gồm file chứa hàm connectToDatabase

// Kiểm tra và bắt đầu phiên làm việc nếu chưa có
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Kiểm tra nếu form đã được submit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $image = $_POST['image'];
    $title = $_POST['title'];
    $publish_date = $_POST['publish_date'];
    $description = $_POST['description'];
    $link = $_POST['link'];

    // Kết nối đến cơ sở dữ liệu
    $conn = connectToDatabase();

    // Thêm tin tức mới vào cơ sở dữ liệu
    $sql = "INSERT INTO news (image, title, publish_date, description, link) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssss", $image, $title, $publish_date, $description, $link);
    if ($stmt->execute()) {
        $_SESSION['message'] = "Tin tức mới đã được thêm thành công!";
        header('Location: Manage.php'); // Chuyển hướng về trang danh sách tin tức
        ob_end_flush(); // Kết thúc bộ đệm đầu ra và gửi nội dung
        exit();
    } else {
        $message = "Có lỗi xảy ra: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>

<!-- thêm tin tức mới -->
<div class="container d-flex justify-content-center">
    <div class="col-md-5 col-10 p-2 m-3 border border-1 rounded-5">
        <h3 class="col-12 text-center py-3">THÊM TIN TỨC MỚI</h3>
        <?php if (isset($message)): ?>
            <div class="alert alert-danger"><?php echo $message; ?></div>
        <?php endif; ?>
        <form action="#" method="POST" class="m-3">
            <div class="user-box">
                <input type="text" id="image" name="image" required>
                <label for="image">Link ảnh minh họa</label>
            </div>
            <div class="user-box">
                <input type="text" id="title" name="title" required>
                <label for="title">Tiêu đề</label>
            </div>
            <div class="user-box">
                <input type="date" id="publish_date" name="publish_date" required>
                <label for="publish_date">Ngày xuất bản</label>
            </div>
            <div class="user-box">
                <textarea class="form-control" id="description" name="description" rows="4" required placeholder="Mô tả tin tức"></textarea>
            </div>
            <div class="user-box">
                <input type="text" id="link" name="link" required>
                <label for="link">Link</label>
            </div>

            <div class="d-grid mt-3">
                <input type="submit" class="btn btn-dark" value="Thêm tin tức mới">
            </div>
        </form>
    </div>
</div>

<?php include('../Footer.php'); ?>