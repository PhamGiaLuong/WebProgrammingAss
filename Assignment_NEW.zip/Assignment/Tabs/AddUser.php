<?php
ob_start(); // Bắt đầu bộ đệm đầu ra
include('../Header.php');
include 'function.php'; // Bao gồm file chứa hàm connectToDatabase

// Kiểm tra và bắt đầu phiên làm việc nếu chưa có
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Kiểm tra nếu form đã được submit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $address = $_POST['address'];

    // Kết nối đến cơ sở dữ liệu
    $conn = connectToDatabase();

    // Thêm nhân viên mới vào cơ sở dữ liệu
    $sql = "INSERT INTO staff (staff_name, staff_phone, staff_email, staff_address) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssss", $name, $phone, $email, $address);
    if ($stmt->execute()) {
        $_SESSION['message'] = "Nhân viên mới đã được thêm thành công!";
        header('Location: Manage.php'); // Chuyển hướng về trang Manage.php
        ob_end_flush(); // Kết thúc bộ đệm đầu ra và gửi nội dung
        exit();
    } else {
        $message = "Có lỗi xảy ra: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>

<!-- thêm nhân viên mới -->
<div class="container d-flex justify-content-center">
    <div class="col-md-5 col-10 p-2 m-3 border border-1 rounded-5">
        <h3 class="col-12 text-center py-3">THÊM NHÂN VIÊN MỚI</h3>
        <?php if (isset($message)): ?>
            <div class="alert alert-danger"><?php echo $message; ?></div>
        <?php endif; ?>
        <form action="#" method="POST" class="m-3">
            <div class="user-box">
                <input type="text" id="name" name="name" required>
                <label for="name">Tên nhân viên</label>
            </div>
            <div class="user-box">
                <input type="text" id="phone" name="phone" required>
                <label for="phone">Số điện thoại</label>
            </div>
            <div class="user-box">
                <input type="email" id="email" name="email" required>
                <label for="email">Email</label>
            </div>
            <div class="user-box">
                <input type="text" id="address" name="address" required>
                <label for="address">Địa chỉ</label>
            </div>

            <div class="d-grid mt-3">
                <input type="submit" class="btn btn-dark" value="Thêm nhân viên mới">
            </div>
        </form>
    </div>
</div>

<?php include('../Footer.php'); ?>