﻿CREATE DATABASE IF NOT EXISTS assigment DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE assigment;

-- Bỏ qua kiểm tra khóa ngoại
SET FOREIGN_KEY_CHECKS = 0;

CREATE TABLE IF NOT EXISTS products (
    product_ID INT(11) NOT NULL AUTO_INCREMENT,
    product_Name TEXT NOT NULL,
    product_Number INT NOT NULL,
    product_IMG VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
    product_Description TEXT,
    product_Price DOUBLE NOT NULL,
    PRIMARY KEY (product_ID)
);

CREATE TABLE IF NOT EXISTS account (
    account_email VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
    account_Name TEXT NOT NULL,
    account_Birthday DATE,
    account_Type VARCHAR(6) NOT NULL,
    account_StartDay DATE NOT NULL,
    account_Address TEXT CHARACTER SET utf8 COLLATE utf8_unicode_ci,
    account_Phone VARCHAR(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
    account_Password VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
    PRIMARY KEY (account_email)
);

CREATE TABLE IF NOT EXISTS cart (
    cart_id INT(11) NOT NULL AUTO_INCREMENT,
    account_email VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
    product_id INT(11) NOT NULL,
    quantity INT(11) NOT NULL,
    added_date DATE NOT NULL,
    PRIMARY KEY (cart_id),
    FOREIGN KEY (account_email) REFERENCES account(account_email),
    FOREIGN KEY (product_id) REFERENCES products(product_ID)
);

CREATE TABLE IF NOT EXISTS orders (
    order_id INT(11) NOT NULL AUTO_INCREMENT,
    account_email VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
    order_date DATE NOT NULL,
    total_amount DOUBLE NOT NULL,
    staff_id INT(11),
    PRIMARY KEY (order_id),
    FOREIGN KEY (account_email) REFERENCES account(account_email),
    FOREIGN KEY (staff_id) REFERENCES staff(staff_id)
);

CREATE TABLE IF NOT EXISTS order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT(11) NOT NULL,
    product_id INT(11) NOT NULL,
    quantity INT NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(order_id),
    FOREIGN KEY (product_id) REFERENCES products(product_ID)
);

CREATE TABLE IF NOT EXISTS staff (
    staff_id INT(11) NOT NULL AUTO_INCREMENT,
    staff_name VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
    staff_phone VARCHAR(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
    staff_email VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
    staff_address TEXT CHARACTER SET utf8 COLLATE utf8_unicode_ci,
    PRIMARY KEY (staff_id)
);

CREATE TABLE IF NOT EXISTS news (
    news_id INT(11) NOT NULL AUTO_INCREMENT,
    image VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
    title VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
    publish_date DATE NOT NULL,
    description TEXT CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
    link VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
    PRIMARY KEY (news_id)
);


-- Bật lại kiểm tra khóa ngoại
SET FOREIGN_KEY_CHECKS = 1;

INSERT INTO products (product_ID, product_Name, product_Number, product_IMG, product_Description, product_Price)
VALUES
    (1, 'Áo thun', 100, "https://product.hstatic.net/1000026602/product/00004171_526efd3d160a48faa58c8c70ca033a2c_master.jpg", 'Áo thun chất liệu cotton, thoáng mát', 150000),
    (2, 'Quần jean', 80, "https://image.uniqlo.com/UQ/ST3/AsianCommon/imagesgoods/463906/item/goods_66_463906_3x4.jpg?width=294", 'Quần jean co giãn, thoải mái', 200000),
    (3, 'Váy', 50, "https://image.hm.com/assets/hm/5f/25/5f2563dea980f6fea707d84ef18f11ed1bb93272.jpg?imwidth=384", 'Váy dài, chất liệu mềm mại', 180000),
    (4, 'Áo sơ mi', 120, "https://cdn.kkfashion.vn/25220-large_default/ao-so-mi-nu-cong-so-mau-trang-tay-dai-asm15-12.jpg", 'Mô tả', 250000),
    (5, 'Quần tây', 100, "https://product.hstatic.net/200000053174/product/24_705e45817844474d801bb701f70c5bb2_master.jpg", 'Quần tây chất liệu vải cao cấp, thoải mái', 50000),
    (6, 'Chân váy', 30, "https://product.hstatic.net/1000392326/product/bjn93369__b__458k__2__797c88a7618c413b8be85dffa0cb53c1_grande.jpg", 'Chân váy xếp ly, chất liệu cao cấp', 300000),
    (7, 'Áo khoác', 70, "https://bizweb.dktcdn.net/thumb/grande/100/415/697/products/ak046.png?v=1701405178907", 'Áo khoác ấm áp, chất liệu cao cấp', 120000),
    (8, 'Áo len', 90, "https://pos.nvncdn.com/778773-105877/ps/20241113_XXRwm2GRYT.jpeg", 'Áo len mềm mại, giữ ấm tốt', 80000),
    (9, 'Quần short', 60, "https://bizweb.dktcdn.com/100/287/440/products/quan-short-local-brand-den-dep-davies-2.jpg?v=1629430404877", 'Quần short thoải mái, phù hợp cho mùa hè', 150000),
    (10, 'Đầm', 20, "https://dytbw3ui6vsu6.cloudfront.net/media/catalog/product/resize/914x1200/M/a/Maje_MFPRO03244-0563_H_P_1_4.webp", 'Đầm dài, thiết kế thanh lịch', 500000),
    (11, 'Áo hoodie', 100, "https://media3.coolmate.me/cdn-cgi/image/quality=80,format=auto/uploads/October2023/ahd.lth.grey.4_copy.jpg", 'Áo hoodie phong cách, giữ ấm tốt', 120000),
    (12, 'Quần legging', 80, "https://image.uniqlo.com/UQ/ST3/AsianCommon/imagesgoods/469844/sub/goods_469844_sub14_3x4.jpg?width=423", 'Quần legging co giãn, thoải mái', 180000),
    (13, 'Áo croptop', 50, "https://cdn.vuahanghieu.com/unsafe/0x900/left/top/smart/filters:quality(90)/https://admin.vuahanghieu.com/upload/product/2023/04/ao-croptop-nu-mlb-varsity-crop-boston-red-sox-3ftsv0333-43whs-tshirt-mau-trang-6430c3c4ab879-08042023083044.jpg", 'Áo croptop phong cách, thoáng mát', 150000),
    (14, 'Quần ống rộng', 40, "https://product.hstatic.net/200000053174/product/2_06de93d0d36741f5aa962865526a71af_master.jpg", 'Quần ống rộng, chất liệu mềm mại', 300000),
    (15, 'Áo hai dây', 100, "https://product.hstatic.net/1000271846/product/01_dc07a847c1f94ab7aeddeba53c08c5c1_master.jpg", 'Áo hai dây, thoải mái, phù hợp cho mùa hè', 80000),
    (16, 'Quần yếm', 60, "https://down-vn.img.susercontent.com/file/2d55ebcc53b79241603198e4a2fe4fa0.webp", 'Quần yếm phong cách, chất liệu cao cấp', 250000),
    (17, 'Áo khoác da', 20, "https://thoitrangbigsize.vn/wp-content/uploads/2023/12/BS2259.jpg", 'Áo khoác da, giữ ấm tốt, phong cách', 500000),
    (18, 'Váy maxi', 80, "https://thoitrangbigsize.vn/wp-content/uploads/2019/12/1-8.jpg", 'Váy maxi dài, chất liệu mềm mại', 50000),
    (19, 'Áo phông', 100, "https://pos.nvncdn.com/778773-105877/ps/20221013_n6HKsuzizp6K2vDgrJLI4qA8.jpg", 'Áo phông chất liệu cotton, thoáng mát', 100000),
    (20, 'Quần jogger', 70, "https://down-vn.img.susercontent.com/file/vn-11134258-7ras8-m36qiu2gehnwd2", 'Quần jogger co giãn, thoải mái', 120000);

