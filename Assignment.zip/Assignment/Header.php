<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
// Kết nối đến cơ sở dữ liệu
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "assigment";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Kết nối thất bại: " . $conn->connect_error);
}

$totalItems = 0;
if (isset($_SESSION['email'])) {
    $email = $_SESSION['email'];

    

    // Lấy tổng số lượng sản phẩm trong giỏ hàng
    $sql = "SELECT SUM(quantity) AS total FROM cart WHERE account_email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $totalItems = $row['total'] ?? 0;

    $stmt->close();
    $conn->close();
}

// Kiểm tra nếu người dùng yêu cầu đăng xuất
if (isset($_GET['action']) && $_GET['action'] == 'logout') {
    // Hủy session
    session_unset();
    session_destroy();
    // Thiết lập thông báo đăng xuất
    session_start();
    $_SESSION['message'] = "Bạn đã đăng xuất";
    // Chuyển hướng về trang Assignment/index.php
    header('Location: ../Assignment/index.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Assignment</title>
    <meta charset="utf-8">
    <meta name="description" content="Assignment">
    <meta name="keywords" content="fashion thời trang">
    <meta name="author" content="AssignmentTeam">
    <meta name="copyright" content="CSE HCMUT 2024">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Round" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Signika+Negative:wght@400;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Asap:wght@400;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=WindSong:wght@400;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Asap:wght@400;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Dancing+Script:wght@400;700&display=swap" rel="stylesheet">
    <link href="/Assignment/style.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</head>

<body>
    <!-- Navigation bar -->
    <div class="navbar nbar navbar-light fixed-top navbar-expand-lg" style="font-family: 'Signika Negative', sans-serif;">
        <div class="container-fluid">
            <a class="navbar-brand" href="/Assignment/index.php">
                <img src="https://hcmut.edu.vn/img/nhanDienThuongHieu/01_logobachkhoatoi.png" alt="Logo" width="60px">
            </a>
            <div class="offcanvas offcanvas-end text-bg-dark" tabindex="-1" id="offcanvasDarkNavbar" aria-labelledby="offcanvasDarkNavbarLabel">
                <div class="offcanvas-header">
                    <h5 class="offcanvas-title" id="offcanvasDarkNavbarLabel">Nhãn Hiệu</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" aria-label="Close"></button>
                </div>
                <div class="offcanvas-body">
                    <ul class="navbar-nav justify-content-end flex-grow-1 pe-3">
                        <li class="nav-item">
                            <a class="nav-link nlink active px-2" aria-current="page" href="/Assignment/index.php" data-tab="home">TRANG CHỦ</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link nlink px-2" href="/Assignment/Tabs/Products.php" data-tab="product">SẢN PHẨM</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link nlink px-2" href="/Assignment/Tabs/Introduction.php" data-tab="introduction">VỀ CHÚNG TÔI</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link nlink px-2" href="/Assignment/Tabs/Contact.php" data-tab="contact">LIÊN HỆ</a>
                        </li>
                    </ul>
                    <form action="/Assignment/Tabs/search.php" method="GET" class="search">
                        <div>
                            <input type="text" name="query" placeholder="Tìm sản phẩm..." required>
                        </div>
                    </form>
                </div>
            </div>
            <ul class="navbar-nav flex-row justify-content-end align-items-center flex-grow-1 gap-2">
                <li class="nav-item">
                    <a class="nav-link position-relative" href="<?php echo isset($_SESSION['email']) ? '/Assignment/Tabs/Cart.php' : '/Assignment/Tabs/SignInOption.php'; ?>">
                        <span class="material-icons-round text-white">shopping_cart</span>
                        <span class="position-absolute top-10 start-90 translate-middle badge rounded-pill bg-danger">
                            <?php echo $totalItems; ?>
                        </span>
                    </a>
                </li>
                <li class="nav-item">
                    <?php if (isset($_SESSION['email'])): ?>
                        <a class="nav-link" href="?action=logout">
                            <span class="material-icons-round text-white">logout</span>
                        </a>
                    <?php else: ?>
                        <a class="nav-link" href="/Assignment/Tabs/SignInOption.php">
                            <span class="material-icons-round text-white">account_circle</span>
                        </a>
                    <?php endif; ?>
                </li>
            </ul>
        </div>
    </div>


    <!-- Hiển thị thông báo -->
    <?php if (isset($_SESSION['message'])): ?>
        <div class="alert alert-success text-center" id="message">
            <?= $_SESSION['message'];
            unset($_SESSION['message']); ?>
        </div>
    <?php endif; ?>

    <!-- Ẩn thông báo sau 3 giây -->
    <script>
        setTimeout(function() {
            var message = document.getElementById('message');
            if (message) {
                message.style.display = 'none';
            }
        }, 3000);
    </script>
</body>

</html>