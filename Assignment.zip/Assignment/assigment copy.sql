﻿CREATE DATABASE IF NOT EXISTS assigment DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE assigment;

CREATE TABLE products(
    product_ID INT(11) NOT NULL,
    product_Name TEXT NOT NULL,
    product_Number INT NOT NULL,
    product_IMG VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
    product_Description TEXT,
    product_Price DOUBLE NOT NULL,
    PRIMARY KEY (product_ID)
);

CREATE TABLE account(
    account_username TEXT NOT NULL,
    account_Name TEXT NOT NULL,
    account_Birthday DATE,
    account_Type VARCHAR(6) NOT NULL,
    account_StartDay DATE NOT NULL,
    PRIMARY KEY (account_username)
);

INSERT INTO products (product_ID, product_Name, product_Number, product_IMG, product_Description, product_Price)
VALUES
    (1, 'Áo thun', 100, "https://product.hstatic.net/1000026602/product/00004171_526efd3d160a48faa58c8c70ca033a2c_master.jpg", 'Áo thun chất liệu cotton, thoáng mát', 150000),
    (2, 'Quần jean', 80, "https://image.uniqlo.com/UQ/ST3/AsianCommon/imagesgoods/463906/item/goods_66_463906_3x4.jpg?width=294", 'Quần jean co giãn, thoải mái', 200000),
    (3, 'Váy', 50, "https://image.hm.com/assets/hm/5f/25/5f2563dea980f6fea707d84ef18f11ed1bb93272.jpg?imwidth=384", 'Váy dài, chất liệu mềm mại', 180000),
    (4, 'Áo sơ mi', 120, "https://cdn.kkfashion.vn/25220-large_default/ao-so-mi-nu-cong-so-mau-trang-tay-dai-asm15-12.jpg", 'Mô tả', 250000),
    (5, 'Quần tây', 100, "https://product.hstatic.net/200000053174/product/24_705e45817844474d801bb701f70c5bb2_master.jpg", 'Quần tây chất liệu vải cao cấp, thoải mái', 50000),
    (6, 'Chân váy', 30, "https://product.hstatic.net/1000392326/product/bjn93369__b__458k__2__797c88a7618c413b8be85dffa0cb53c1_grande.jpg", 'Chân váy xếp ly, chất liệu cao cấp', 300000),
    (7, 'Áo khoác', 70, "https://bizweb.dktcdn.net/thumb/grande/100/415/697/products/ak046.png?v=1701405178907", 'Áo khoác ấm áp, chất liệu cao cấp', 120000),
    (8, 'Áo len', 90, "https://pos.nvncdn.com/778773-105877/ps/20241113_XXRwm2GRYT.jpeg", 'Áo len mềm mại, giữ ấm tốt', 80000),
    (9, 'Quần short', 60, "https://bizweb.dktcdn.com/100/287/440/products/quan-short-local-brand-den-dep-davies-2.jpg?v=1629430404877", 'Quần short thoải mái, phù hợp cho mùa hè', 150000),
    (10, 'Đầm', 20, "https://dytbw3ui6vsu6.cloudfront.net/media/catalog/product/resize/914x1200/M/a/Maje_MFPRO03244-0563_H_P_1_4.webp", 'Đầm dài, thiết kế thanh lịch', 500000),
    (11, 'Áo hoodie', 100, "https://media3.coolmate.me/cdn-cgi/image/quality=80,format=auto/uploads/October2023/ahd.lth.grey.4_copy.jpg", 'Áo hoodie phong cách, giữ ấm tốt', 120000),
    (12, 'Quần legging', 80, "https://image.uniqlo.com/UQ/ST3/AsianCommon/imagesgoods/469844/sub/goods_469844_sub14_3x4.jpg?width=423", 'Quần legging co giãn, thoải mái', 180000),
    (13, 'Áo croptop', 50, "https://cdn.vuahanghieu.com/unsafe/0x900/left/top/smart/filters:quality(90)/https://admin.vuahanghieu.com/upload/product/2023/04/ao-croptop-nu-mlb-varsity-crop-boston-red-sox-3ftsv0333-43whs-tshirt-mau-trang-6430c3c4ab879-08042023083044.jpg", 'Áo croptop phong cách, thoáng mát', 150000),
    (14, 'Quần ống rộng', 40, "https://product.hstatic.net/200000053174/product/2_06de93d0d36741f5aa962865526a71af_master.jpg", 'Quần ống rộng, chất liệu mềm mại', 300000),
    (15, 'Áo hai dây', 100, "https://product.hstatic.net/1000271846/product/01_dc07a847c1f94ab7aeddeba53c08c5c1_master.jpg", 'Áo hai dây, thoải mái, phù hợp cho mùa hè', 80000),
    (16, 'Quần yếm', 60, "https://down-vn.img.susercontent.com/file/2d55ebcc53b79241603198e4a2fe4fa0.webp", 'Quần yếm phong cách, chất liệu cao cấp', 250000),
    (17, 'Áo khoác da', 20, "https://thoitrangbigsize.vn/wp-content/uploads/2023/12/BS2259.jpg", 'Áo khoác da, giữ ấm tốt, phong cách', 500000),
    (18, 'Váy maxi', 80, "https://thoitrangbigsize.vn/wp-content/uploads/2019/12/1-8.jpg", 'Váy maxi dài, chất liệu mềm mại', 50000),
    (19, 'Áo phông', 100, "https://pos.nvncdn.com/778773-105877/ps/20221013_n6HKsuzizp6K2vDgrJLI4qA8.jpg", 'Áo phông chất liệu cotton, thoáng mát', 100000),
    (20, 'Quần jogger', 70, "https://down-vn.img.susercontent.com/file/vn-11134258-7ras8-m36qiu2gehnwd2", 'Quần jogger co giãn, thoải mái', 120000);

INSERT INTO account (account_username, account_Name, account_Birthday, account_Type, account_StartDay)
VALUES
    ('abb', 'Nguyễn Văn An Nam', '2000-03-15', 'Admin', '2022-11-20'),
    ('bbb', 'Trần Thị Bình', '2002-08-21', 'Member', '2023-12-10'),
    ('cbb', 'Hồ Ngọc Minh Châu', '2005-07-12', 'Member', '2022-10-05'),
    ('dbb', 'Lê Văn Đức', '2001-04-03', 'Member', '2024-01-22'),
    ('ebb', 'Phạm Thị Thu Hà', '2006-01-25', 'Member', '2023-07-19'),
    ('fbb', 'Võ Văn Hoàng', '2003-02-18', 'Member', '2022-09-30'),
    ('gbb', 'Đặng Thị Kim Ngân', '2004-06-10', 'Member', '2024-03-11'),
    ('hbb', 'Bùi Văn Quang', '2000-11-04', 'Member', '2023-11-26'),
    ('ibb', 'Nguyễn Thị Thu Thủy', '2002-09-09', 'Member', '2024-02-17'),
    ('jbb', 'Trần Văn Trung', '2007-01-30', 'Member', '2022-08-13');
