<?php
ob_start(); // Bắt đầu bộ đệm đầu ra
include('../Header.php');

// Kiểm tra và bắt đầu phiên làm việc nếu chưa có
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include 'function.php'; // Bao gồm file chứa hàm connectToDatabase

// Giả sử email người dùng đã lưu trong session
$email = $_SESSION['email'];

// Kết nối đến cơ sở dữ liệu
$conn = connectToDatabase();

// Xử lý cập nhật số lượng và xóa sản phẩm trong giỏ hàng
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update_cart'])) {
        $product_id = $_POST['product_id'];
        $quantity = $_POST['quantity'];
        updateCart($email, $product_id, $quantity);
    } elseif (isset($_POST['delete_cart'])) {
        $product_id = $_POST['product_id'];
        deleteFromCart($email, $product_id);
    } elseif (isset($_POST['place_order'])) {
        placeOrder($email); // Gọi hàm xử lý đặt hàng và lưu tổng giá trị đơn hàng
        header('Location: OrderHistory.php'); // Chuyển đến trang lịch sử đơn hàng sau khi đặt hàng thành công
        ob_end_flush(); // Kết thúc bộ đệm đầu ra và gửi nội dung
        exit();
    }
}

// Lấy thông tin người dùng từ cơ sở dữ liệu
$sql = "SELECT account_Name, account_Phone, account_Address FROM account WHERE account_email = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

// Lấy thông tin giỏ hàng từ cơ sở dữ liệu
$sql_cart = "SELECT cart.product_id, cart.quantity, products.product_Name, products.product_Price, products.product_IMG 
             FROM cart 
             JOIN products ON cart.product_id = products.product_ID 
             WHERE cart.account_email = ?";
$stmt_cart = $conn->prepare($sql_cart);
$stmt_cart->bind_param("s", $email);
$stmt_cart->execute();
$result_cart = $stmt_cart->get_result();
$cartItems = $result_cart->fetch_all(MYSQLI_ASSOC);

$stmt->close();
$stmt_cart->close();
$conn->close();
?>

<!-- Hiển thị giỏ hàng -->
<div class="container my-3">
    <h1 class="text-center mb-4">Giỏ Hàng Của Bạn</h1>
    <!-- Thông tin đặt hàng -->
    <div class="col-12">
        <div class="col-12 px-2 d-flex flex-wrap">
            <h6 class="col-2 fw-bold">Họ tên: </h6>
            <span><?php echo htmlspecialchars($user['account_Name']); ?></span>
        </div>
        <div class="col-12 px-2 d-flex flex-wrap">
            <h6 class="col-2 fw-bold">SĐT: </h6>
            <span><?php echo htmlspecialchars($user['account_Phone']); ?></span>
        </div>
        <div class="col-12 px-2 d-flex flex-wrap">
            <h6 class="col-2 fw-bold">Email: </h6>
            <span><?php echo htmlspecialchars($email); ?></span>
        </div>
        <div class="col-12 px-2 d-flex flex-wrap">
            <h6 class="col-2 fw-bold">Địa chỉ: </h6>
            <span><?php echo htmlspecialchars($user['account_Address']); ?></span>
        </div>
    </div>

    <!-- Nút nhấn chuyển đến lịch sử mua hàng -->
    <div class="col-12 d-flex justify-content-end">
        <div class="col-md-3 col-6 text-center p-2" style="background-color: #222f3e;">
            <a href="/Assignment/Tabs/OrderHistory.php" style="color: white;"><i class="bi bi-receipt-cutoff"></i> Xem lịch sử đơn hàng</a>
        </div>
    </div>

    <!-- Bảng hiển thị giỏ hàng -->
    <table class="table border-0 mt-1">
        <thead class="table-dark">
            <tr>
                <th>STT</th>
                <th class="d-md-block d-none">Hình ảnh</th>
                <th>Tên sản phẩm</th>
                <th>Số lượng</th>
                <th>Đơn giá</th>
                <th>Thành tiền</th>
                <th>Hành động</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $totalQuantity = 0;
            $totalPrice = 0;

            foreach ($cartItems as $index => $item):
                $itemTotal = $item['quantity'] * $item['product_Price'];
                $totalQuantity += $item['quantity'];
                $totalPrice += $itemTotal;
            ?>
                <tr style="border-bottom: 1px solid #576574; vertical-align: middle;">
                    <td><?= $index + 1; ?></td>
                    <td class="d-md-block d-none border-0">
                        <img src="<?= htmlspecialchars($item['product_IMG']); ?>" alt="<?= htmlspecialchars($item['product_Name']); ?>" style="width: 100px; height: auto;">
                    </td>
                    <td><?= htmlspecialchars($item['product_Name']); ?></td>
                    <td>
                        <div class="d-flex align-items-center">
                            <button type="button" class="btn btn-secondary" onclick="updateQuantity(<?= $item['product_id']; ?>, <?= $item['quantity'] - 1; ?>)">-</button>
                            <input type="number" name="quantity" value="<?= $item['quantity']; ?>" min="1" class="form-control mx-2 text-center" style="width: 60px;" onchange="updateQuantity(<?= $item['product_id']; ?>, this.value)">
                            <button type="button" class="btn btn-secondary" onclick="updateQuantity(<?= $item['product_id']; ?>, <?= $item['quantity'] + 1; ?>)">+</button>
                        </div>
                    </td>
                    <td><?= number_format($item['product_Price'], 0, ',', '.') . ' VND'; ?></td>
                    <td><?= number_format($itemTotal, 0, ',', '.') . ' VND'; ?></td>
                    <td>
                        <form method="POST" action="">
                            <input type="hidden" name="product_id" value="<?= $item['product_id']; ?>">
                            <button type="submit" name="delete_cart" class="btn btn-danger"><i class="bi bi-trash"></i></button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <div class="col-12 d-flex flex-wrap justify-content-between align-items-center mt-4 fs-4">
        <div class="col-md-5 col-12">
            <strong>Tổng số lượng sản phẩm: <?= $totalQuantity; ?></strong>
        </div>
        <div class="col-md-5 col-12">
            <strong>Tổng tiền: <?= number_format($totalPrice, 0, ',', '.') . ' VND'; ?></strong>
        </div>
        <div class="col-md-2 col-12">
            <form method="POST" action="">
                <button type="submit" name="place_order" class="btn btn-success w-100">Đặt hàng</button>
            </form>
        </div>
    </div>
</div>

<?php include('../Footer.php'); ?>

<script>
    function updateQuantity(productId, quantity) {
        const form = document.createElement('form');
        form.method = 'POST';
        form.action = '';

        const inputProductId = document.createElement('input');
        inputProductId.type = 'hidden';
        inputProductId.name = 'product_id';
        inputProductId.value = productId;
        form.appendChild(inputProductId);

        const inputQuantity = document.createElement('input');
        inputQuantity.type = 'hidden';
        inputQuantity.name = 'quantity';
        inputQuantity.value = quantity;
        form.appendChild(inputQuantity);

        const inputUpdate = document.createElement('input');
        inputUpdate.type = 'hidden';
        inputUpdate.name = 'update_cart';
        inputUpdate.value = 'true';
        form.appendChild(inputUpdate);

        document.body.appendChild(form);
        form.submit();
    }
</script>