<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include 'function.php';
$conn = connectToDatabase();

// Kiểm tra nếu người dùng đã đăng nhập
if (!isset($_SESSION['email'])) {
    header('Location: /Assignment/Tabs/SignInOption.php');
    exit();
}

$email = $_SESSION['email'];
$product_ID = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Xử lý thêm sản phẩm vào giỏ hàng
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $quantity = isset($_POST['quantity']) ? (int)$_POST['quantity'] : 1;
    if (isset($_POST['add_to_cart'])) {
        addToCart($email, $product_ID, $quantity);
    } elseif (isset($_POST['buy_now'])) {
        addToCart($email, $product_ID, $quantity);
        header('Location: Cart.php');
        exit();
    }
}

// Kiểm tra nếu ID sản phẩm hợp lệ
if ($product_ID > 0) {
    // Truy vấn thông tin chi tiết sản phẩm
    $sql = "SELECT * FROM products WHERE product_ID = $product_ID";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Lấy thông tin chi tiết sản phẩm
        $product = $result->fetch_assoc();
    } else {
        echo "<p>Không tìm thấy sản phẩm.</p>";
        $product = null;
    }
} else {
    echo "<p>ID sản phẩm không hợp lệ.</p>";
    $product = null;
}
?>

<?php include('../Header.php'); ?>

<?php if ($product): ?>
    <!-- tab Chi tiết sản phẩm -->
    <div class="container d-flex flex-wrap mt-4">
        <!-- Breadcrumb -->
        <div class="col-12">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="/Assignment/Tabs/Products.php">Products</a></li>
                    <li class="breadcrumb-item"><a href="#">Clothing</a></li>
                    <li class="breadcrumb-item active" aria-current="page"><?= htmlspecialchars($product['product_Name'], ENT_QUOTES, 'UTF-8'); ?></li>
                </ol>
            </nav>
        </div>

        <!-- Cột hiển thị hình ảnh sản phẩm lớn với trình chiếu hình ảnh tự động -->
        <div class="col-md-7 col-12" style="height: 60vh;">
            <div id="productImageCarousel" class="carousel slide h-100" data-bs-ride="carousel" style="overflow: hidden;">
                <div class="carousel-inner h-100">
                    <div class="carousel-item active h-100">
                        <img src="<?= htmlspecialchars($product['product_IMG'], ENT_QUOTES, 'UTF-8'); ?>" class="d-block w-100 h-100" alt="<?= htmlspecialchars($product['product_Name'], ENT_QUOTES, 'UTF-8'); ?>" style="object-fit: contain;">
                    </div>
                    <!-- Thêm các hình ảnh khác nếu cần -->
                </div>
                <button class="carousel-control-prev" type="button" data-bs-target="#productImageCarousel" data-bs-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Previous</span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#productImageCarousel" data-bs-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Next</span>
                </button>
            </div>
        </div>

        <div class="col-md-5 col-12 p-2 text-center">
            <h2><?= htmlspecialchars($product['product_Name'], ENT_QUOTES, 'UTF-8'); ?></h2>
            <h2><?= number_format($product['product_Price'], 0, ',', '.'); ?> VND</h2>
            <form method="POST" action="">
                <div class="d-flex justify-content-center align-items-center mb-3">
                    <button type="button" id="decreaseBtn" class="btn btn-secondary">-</button>
                    <input type="number" id="quantityInput" name="quantity" value="1" min="1" class="form-control mx-2 text-center" style="width: 60px;" readonly>
                    <button type="button" id="increaseBtn" class="btn btn-secondary">+</button>
                </div>

                <button type="submit" name="add_to_cart" class="btn btn-outline-danger w-50 my-2">Thêm vào giỏ hàng</button>
                <button type="submit" name="buy_now" class="btn btn-danger w-50 my-2">Mua ngay</button>
            </form>
            <div class="col-12 d-flex flex-wrap justify-content-around gap-1">
                <a href="" class="border-b fade-in p-2">Áo nam</a>
                <a href="" class="border-b fade-in p-2">Bán chạy</a>
                <a href="" class="border-b fade-in p-2">Bộ sưu tập NA</a>
                <a href="" class="border-b fade-in p-2">Thun lạnh</a>
                <a href="" class="border-b fade-in p-2">Oversize</a>
                <a href="" class="border-b fade-in p-2">Tay dài</a>
                <a href="" class="border-b fade-in p-2">Cổ cao</a>
            </div>
        </div>
    </div>
    </div>
<?php endif; ?>

<?php include('../Footer.php'); ?>

<script>
    // JavaScript để thay đổi số lượng sản phẩm
    document.getElementById('decreaseBtn').addEventListener('click', function() {
        var quantityInput = document.getElementById('quantityInput');
        if (quantityInput.value > 1) {
            quantityInput.value--;
        }
    });

    document.getElementById('increaseBtn').addEventListener('click', function() {
        var quantityInput = document.getElementById('quantityInput');
        quantityInput.value++;
    });
</script>

<?php
$conn->close() ?>