<?php
session_start();
include 'function.php'; // Bao gồm file chứa hàm connectToDatabase và checkEmailExists

if (isset($_POST['register']) && ($_POST['register'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];
    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];
    $birthday = $_POST['birthday'];
    $type = "user";
    $startDay = date('Y-m-d');

    // Kiểm tra nếu email đã tồn tại
    if (checkEmailExists($email)) {
        $message = "<span style='color: red;'>Email đã tồn tại. Vui lòng sử dụng email khác.</span>";
    } else {
        // Kết nối đến cơ sở dữ liệu
        $conn = connectToDatabase();

        // Thêm tài khoản mới vào cơ sở dữ liệu
        $sql = "INSERT INTO account (account_email, account_Name, account_Birthday, account_Type, account_StartDay, account_Address, account_Phone, account_Password) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssssss", $email, $name, $birthday, $type, $startDay, $address, $phone, $password);

        if ($stmt->execute()) {
            // Chuyển hướng về trang SignInOption.php nếu đăng ký thành công
            header('Location: SignInOption.php');
            exit();
        } else {
            $message = "<span style='color: red;'>Đã xảy ra lỗi. Vui lòng thử lại.</span>";
        }

        $stmt->close();
        $conn->close();
    }
}

function checkEmailExists($email)
{
    $conn = connectToDatabase();
    $sql = "SELECT * FROM account WHERE account_email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    $emailExists = $result->num_rows > 0;
    $stmt->close();
    $conn->close();
    return $emailExists;
}
?>

<!-- tab Đăng ký -->
<?php include('../Header.php'); ?>
<div class="col-12 d-flex flex-wrap justify-content-md-between justify-content-center">
    <div class="col-3 d-none d-md-flex flex-wrap align-items-end">
        <img src="/Assignment/Images/left2.png" class="img-fluid" alt="left.png">
    </div>
    <div class="col-md-4 col-11 d-flex flex-wrap justify-content-center align-items-center">
        <div class="col-11 d-flex flex-wrap justify-content-center align-items-center rounded-5 my-2 sign-box pb-2">
            <div class="col-12 d-flex flex-wrap justify-content-center pt-3 rounded-bottom-0 rounded-5" style="background-color: #222f3e;">
                <img src="https://th.bing.com/th/id/OIP.3nmDniLn753Ub3m0acgBjAHaHe?rs=1&pid=ImgDetMain" alt="logo" width="60">
                <h1 class="text-center col-12 my-3" style="font-family: 'WindSong', san-serif; color: white;">
                    xin chào
                </h1>
            </div>
            <form action="SignUp.php" method="POST" class="p-3 col-12">
                <div class="user-box">
                    <input type="text" id="name" name="name" required>
                    <label for="name">Họ tên</label>
                </div>
                <div class="user-box">
                    <input type="text" id="phone" name="phone" required>
                    <label for="phone">Số điện thoại</label>
                </div>
                <div class="user-box">
                    <input type="email" id="email" name="email" required>
                    <label for="email">Email</label>
                    <?php if (isset($message) && strpos($message, 'Email đã tồn tại') !== false): ?>
                        <span style="color: red;">Email đã tồn tại. Vui lòng sử dụng email khác.</span>
                    <?php endif; ?>
                </div>
                <div class="user-box">
                    <input type="text" id="address" name="address" required>
                    <label for="address">Địa chỉ</label>
                </div>
                <div class="user-box">
                    <input type="date" id="birthday" name="birthday" required>
                    <label for="birthday">Ngày sinh</label>
                </div>
                <div class="user-box">
                    <input type="password" id="password" name="password" required>
                    <label for="password">Mật Khẩu</label>
                </div>
                <div class="user-box">
                    <input type="password" id="rePassword" name="rePassword" required>
                    <label for="rePassword">Nhập lại mật Khẩu</label>
                </div>
                <div class="d-grid">
                    <input type="submit" class="btn btn-dark" name="register" value="Đăng ký">
                </div>
                <?php
                if (isset($message) && strpos($message, 'Email đã tồn tại') === false) {
                    echo $message;
                }
                ?>
            </form>
            <div class="col-12 m-2 text-center">
                <a href="SignIn.php" class="text-dark">Bạn đã có tài khoản? <strong>Đăng nhập ngay!</strong></a>
            </div>
        </div>
    </div>
    <div class="col-3 d-none d-md-flex flex-wrap align-items-end">
        <img src="/Assignment/Images/right2.png" class="img-fluid" alt="right.png">
    </div>
</div>
<?php include('../Footer.php'); ?>