<?php function connectToDatabase()
{
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "assigment";
    // Tạo kết nối 
    $conn = new mysqli($servername, $username, $password, $dbname);
    // Kiểm tra kết nối 
    if ($conn->connect_error) {
        die("Kết nối thất bại: " . $conn->connect_error);
    }
    return $conn;
}

// Hàm để lấy thông tin sản phẩm từ cơ sở dữ liệu
function getProducts($conn)
{
    $sql = "SELECT product_ID, product_Name, product_Price, product_IMG FROM products";
    $result = $conn->query($sql);

    $products = [];
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $products[] = [
                $row['product_ID'],
                $row['product_Name'],
                $row['product_Price'],
                $row['product_IMG']
            ];
        }
    } else {
        echo "Không có sản phẩm nào trong cơ sở dữ liệu.<br>";
    }
    return $products;
}

function addToCart($email, $productID, $quantity)
{
    $conn = connectToDatabase();
    // Kiểm tra nếu sản phẩm đã có trong giỏ hàng 
    $sql_check = "SELECT * FROM cart WHERE account_email = ? AND product_id = ?";
    $stmt_check = $conn->prepare($sql_check);
    $stmt_check->bind_param("si", $email, $productID);
    $stmt_check->execute();
    $result_check = $stmt_check->get_result();
    if ($result_check->num_rows > 0) {
        // Nếu sản phẩm đã có trong giỏ hàng, cập nhật số lượng 
        $sql_update = "UPDATE cart SET quantity = quantity + ? WHERE account_email = ? AND product_id = ?";
        $stmt_update = $conn->prepare($sql_update);
        $stmt_update->bind_param("isi", $quantity, $email, $productID);
        $stmt_update->execute();
        $stmt_update->close();
    } else {
        // Nếu sản phẩm chưa có trong giỏ hàng, thêm sản phẩm mới
        $sql_insert = "INSERT INTO cart (account_email, product_id, quantity, added_date) VALUES (?, ?, ?, CURDATE())";
        $stmt_insert = $conn->prepare($sql_insert);
        $stmt_insert->bind_param("sii", $email, $productID, $quantity);
        $stmt_insert->execute();
        $stmt_insert->close();
    }
    $stmt_check->close();
    $conn->close();
}

function updateCart($email, $product_id, $quantity)
{
    $conn = connectToDatabase();
    $sql = "UPDATE cart SET quantity = ? WHERE account_email = ? AND product_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("isi", $quantity, $email, $product_id);
    $stmt->execute();
    $stmt->close();
    $conn->close();
}

function deleteFromCart($email, $product_id)
{
    $conn = connectToDatabase();
    $sql = "DELETE FROM cart WHERE account_email = ? AND product_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("si", $email, $product_id);
    $stmt->execute();
    $stmt->close();
    $conn->close();
}

function placeOrder($email)
{
    $conn = connectToDatabase();

    // Lấy thông tin giỏ hàng từ cơ sở dữ liệu
    $sql_cart = "SELECT cart.product_id, cart.quantity, products.product_Price 
                 FROM cart 
                 JOIN products ON cart.product_id = products.product_ID 
                 WHERE cart.account_email = ?";
    $stmt_cart = $conn->prepare($sql_cart);
    $stmt_cart->bind_param("s", $email);
    $stmt_cart->execute();
    $result_cart = $stmt_cart->get_result();
    $cartItems = $result_cart->fetch_all(MYSQLI_ASSOC);

    $totalAmount = 0;

    // Tính tổng giá trị đơn hàng
    foreach ($cartItems as $item) {
        $totalAmount += $item['quantity'] * $item['product_Price'];
    }

    // Thêm đơn hàng mới vào bảng `orders`
    $sql_order = "INSERT INTO orders (account_email, order_date, total_amount) VALUES (?, NOW(), ?)";
    $stmt_order = $conn->prepare($sql_order);
    $stmt_order->bind_param("sd", $email, $totalAmount);
    $stmt_order->execute();
    $order_id = $stmt_order->insert_id;
    $stmt_order->close();

    // Thêm từng sản phẩm trong giỏ hàng vào bảng `order_items`
    $sql_order_item = "INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)";
    $stmt_order_item = $conn->prepare($sql_order_item);

    foreach ($cartItems as $item) {
        $product_id = $item['product_id'];
        $quantity = $item['quantity'];
        $price = $item['product_Price'];
        $stmt_order_item->bind_param("iiid", $order_id, $product_id, $quantity, $price);
        $stmt_order_item->execute();
    }

    $stmt_order_item->close();

    // Xóa giỏ hàng sau khi đặt hàng thành công
    $sql_clear_cart = "DELETE FROM cart WHERE account_email = ?";
    $stmt_clear_cart = $conn->prepare($sql_clear_cart);
    $stmt_clear_cart->bind_param("s", $email);
    $stmt_clear_cart->execute();
    $stmt_clear_cart->close();

    $conn->close();
}
